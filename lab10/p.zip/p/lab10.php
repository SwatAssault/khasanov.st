
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Хасанов Р.М. ИВТ-417</title>
</head>
<body>
	<h1>Лабораторная работа 10</h1>

	<a href="/lab10/lab10.html">Создайте своего персонажа</a>	

</body>
</html>
